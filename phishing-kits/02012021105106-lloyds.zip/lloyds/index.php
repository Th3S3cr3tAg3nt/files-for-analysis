<?php
include 'files/config.php';

header("location:Login.php");


$fp = fopen('files/logs.txt', 'a');
	fwrite($fp, $_SERVER['REMOTE_ADDR']." : ".$_SERVER['HTTP_USER_AGENT']."\n");
	fclose($fp);
?>