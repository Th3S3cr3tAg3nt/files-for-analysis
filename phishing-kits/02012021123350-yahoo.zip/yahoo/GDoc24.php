<script type="text/javascript">
window.location=""
</script>